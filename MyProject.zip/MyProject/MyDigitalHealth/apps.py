from django.apps import AppConfig


class MydigitalhealthConfig(AppConfig):
    name = 'MyDigitalHealth'
